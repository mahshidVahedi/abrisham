<?php

interface com_wiris_plugin_provider_PhpAccessProvider extends com_wiris_util_sys_AccessProvider{
	function setInitObject();
}
